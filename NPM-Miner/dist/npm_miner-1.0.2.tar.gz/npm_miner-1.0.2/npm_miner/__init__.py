"""NPM package miner."""

__version__ = "1.0.0"

from .miner import mine_npm_packages

__all__ = ["mine_npm_packages"]
