"""Crates.io package miner."""

__version__ = "1.0.0"

from .miner import mine_crates

__all__ = ["mine_crates"]
