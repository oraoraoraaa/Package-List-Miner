"""RubyGems package miner."""

__version__ = "1.0.0"

from .miner import mine_ruby_gems

__all__ = ["mine_ruby_gems"]
