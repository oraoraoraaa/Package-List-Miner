"""PyPI package miner."""

__version__ = "1.0.0"

from .miner import mine_pypi_packages

__all__ = ["mine_pypi_packages"]
