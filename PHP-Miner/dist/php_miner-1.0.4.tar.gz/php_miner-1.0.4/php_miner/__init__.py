"""PHP/Packagist package miner."""

__version__ = "1.0.0"

from .miner import mine_php_packages

__all__ = ["mine_php_packages"]
