"""Go modules package miner."""

__version__ = "1.0.0"

from .miner import mine_go_packages

__all__ = ["mine_go_packages"]
